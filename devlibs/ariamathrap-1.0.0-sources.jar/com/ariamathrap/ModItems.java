package com.ariamathrap;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.RecordItem;

public class ModItems {
    public static final Item CUSTOM_DISC = registerItem("custom_disc",
            new RecordItem(15, SoundEvents.MUSIC_DISC_PIGSTEP, new Item.Properties().stacksTo(1), 100));

    public static final CreativeModeTab ARIAMATHRAP_TAB = Registry.register(
            BuiltInRegistries.CREATIVE_MODE_TAB,
            new ResourceLocation(Ariamathrap.MOD_ID, "ariamathrap_tab"),
            FabricItemGroup.builder()
                    .title(Component.translatable("itemgroup.ariamathrap.ariamathrap_tab"))
                    .icon(() -> new ItemStack(CUSTOM_DISC))
                    .displayItems((parameters, output) -> {
                        output.accept(CUSTOM_DISC);
                    }).build()
    );

    private static Item registerItem(String name, Item item) {
        return Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(Ariamathrap.MOD_ID, name), item);
    }

    public static void registerModItems() {
        Ariamathrap.LOGGER.info("Registering Mod Items for " + Ariamathrap.MOD_ID);
    }
}


