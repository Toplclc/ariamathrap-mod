package com.ariamathrap;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Ariamathrap implements ModInitializer {
	public static final String MOD_ID = "ariamathrap";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// This line is crucial! It tells the game to run your item registration.
		ModItems.registerModItems();
		LOGGER.info("Ariamathrap mod initialized successfully!");
	}
}